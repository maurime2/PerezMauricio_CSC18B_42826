//Libraries
package final18b;
import javax.swing.JFrame;

//Class Final18B
public class Final18B {

    //Main Start
    public static void main(String[] args) {
      //New Text Frame
      Display display = new Display(); 
      display.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      display.setSize(500, 500); 
      display.setVisible(true); 
    }//Main End
    
}
