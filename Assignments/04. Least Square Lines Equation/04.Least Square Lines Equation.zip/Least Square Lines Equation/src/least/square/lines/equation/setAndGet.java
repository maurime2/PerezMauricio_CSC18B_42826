//Libraries
package least.square.lines.equation;

//SetAndGet Class
public class setAndGet {
    
}
